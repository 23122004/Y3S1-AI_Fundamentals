"""Continuous optimization experiments."""
