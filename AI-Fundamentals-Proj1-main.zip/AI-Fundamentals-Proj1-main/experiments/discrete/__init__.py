"""Discrete optimization experiments."""
