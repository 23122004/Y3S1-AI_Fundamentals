"""Continuous optimization algorithms."""
