"""Discrete optimization algorithms."""
