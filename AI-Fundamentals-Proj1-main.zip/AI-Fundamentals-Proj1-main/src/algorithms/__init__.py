"""Optimization algorithms package."""
