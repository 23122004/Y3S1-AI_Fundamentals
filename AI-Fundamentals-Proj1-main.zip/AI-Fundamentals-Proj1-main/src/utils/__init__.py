"""Utility functions and visualizations."""
